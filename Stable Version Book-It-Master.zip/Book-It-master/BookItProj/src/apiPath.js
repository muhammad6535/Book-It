const apiPath = 'http://localhost:5001/api'
export default apiPath
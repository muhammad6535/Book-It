const apiPath = "http://10.0.2.2:5001/api";
export default apiPath;
